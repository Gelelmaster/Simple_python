import numpy as np
import logging
import soundfile as sf
import io
from pygame import mixer
from Synthesizers.base import Base_TTS_Synthesizer, Base_TTS_Task
from importlib import import_module
from src.common_config_manager import app_config
import torch
import asyncio
import threading

# 设置日志级别
for logger_name in [
    "markdown_it", "urllib3", "httpcore", "httpx",
    "asyncio", "charset_normalizer", "torchaudio._extension"
]:
    logging.getLogger(logger_name).setLevel(logging.ERROR)

# 检查CUDA可用性
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using {'GPU' if torch.cuda.is_available() else 'CPU'} for inference.")

# 动态导入语音合成器模块
synthesizer_name = app_config.synthesizer
synthesizer_module = import_module(f"Synthesizers.{synthesizer_name}")
TTS_Synthesizer = synthesizer_module.TTS_Synthesizer
TTS_Task = synthesizer_module.TTS_Task

# 创建合成器实例
tts_synthesizer: Base_TTS_Synthesizer = TTS_Synthesizer(debug_mode=True)

# 初始化音频播放库
mixer.init()
characters_and_emotions_dict = {}
stop_playing = threading.Event()  # 用于控制播放状态

def get_characters_and_emotions():
    """获取角色和情感信息"""
    global characters_and_emotions_dict
    if not characters_and_emotions_dict:
        characters_and_emotions_dict = tts_synthesizer.get_characters()
        print("可用角色及情感：", characters_and_emotions_dict)
    return characters_and_emotions_dict

async def get_audio(data):
    """生成音频数据"""
    if not data.get("text"):
        raise ValueError("文本不能为空")
    try:
        task: Base_TTS_Task = tts_synthesizer.params_parser(data)
        # 将任务数据移到 GPU（如果支持）
        if hasattr(task, 'to'):
            task = task.to(device)
        gen = tts_synthesizer.generate(task, return_type="numpy")
        audio_data = next(gen)  # 直接生成音频数据
        print(f"生成的音频数据（元组）: {audio_data}, 长度: {len(audio_data)}")
        return audio_data
    except Exception as e:
        raise RuntimeError(f"错误: {e}")

async def play_audio(audio_data, sample_rate=32000):
    """播放生成的音频数据"""
    print(f"音频数据类型: {type(audio_data)}, 长度: {len(audio_data)}")

    # 如果 audio_data 是元组，提取音频数据和采样率
    if isinstance(audio_data, tuple):
        sample_rate, audio_data = audio_data
        print(f"提取音频数据: {audio_data}, 采样率: {sample_rate}")

    audio_data = np.array(audio_data)

    # 确保音频数据为一维数组
    if audio_data.ndim == 1:
        audio_data = audio_data.reshape(-1, 1)
    elif audio_data.ndim > 2:
        raise ValueError("不支持的音频数据维度")

    print(f"处理后的音频数据形状: {audio_data.shape}")

    # 将音频数据保存到内存中的文件对象
    with io.BytesIO() as virtual_file:
        # 将 numpy 数组中的音频数据写入虚拟文件
        sf.write(virtual_file, audio_data, sample_rate, format='WAV')
        virtual_file.seek(0)  # 重置文件指针到开始位置

        mixer.music.load(virtual_file, 'wav')
        mixer.music.play()

        # 使用 asyncio 进行音频播放的监听
        while mixer.music.get_busy():
            if stop_playing.is_set():
                mixer.music.stop()  # 停止音频播放
                print("音频播放已被打断。")
                break
            await asyncio.sleep(0.1)  # 等待音频播放结束

async def listen_for_enter():
    """监听回车键以中断音频播放"""
    input("按下回车键以中断音频播放...")
    stop_playing.set()  # 设置停止播放标志

async def text_to_speech(text, character="", emotion="default"):
    """文本转语音流程"""
    data = {"text": text, "character": character, "emotion": emotion}
    print("开始生成音频...")
    
    audio_data = await get_audio(data)
    if audio_data is None or len(audio_data) == 0:
        print("没有生成有效的音频数据。")
        return False  # 如果没有音频数据，返回 False

    print("生成完成，正在播放音频...")

    # 启动监听线程
    asyncio.create_task(listen_for_enter())  # 开始监听回车键

    await play_audio(audio_data)  # 播放音频

    if stop_playing.is_set():  # 检查是否被打断
        cont = input("继续吗？(y/n)：")
        if cont.lower() != 'y':
            return True  # 返回 True 表示要退出

    return False  # 默认返回 False，表示未要求退出

async def main():
    """主函数，接受用户输入并启动TTS"""
    get_characters_and_emotions()

    character_names = list(characters_and_emotions_dict.keys())
    print("可用角色：", character_names)
    character = input("选择角色（按回车键选择默认角色）：")
    if character not in character_names:
        character = character_names[0] if character_names else ""

    emotion_options = characters_and_emotions_dict.get(character, ["default"])
    print(f"{character} 可用情感：", emotion_options)
    emotion = input("选择情感（按回车键选择默认情感）：")
    if emotion not in emotion_options:
        emotion = "default"

    while True:
        text = input("请输入要转换为语音的文本：")
        # 生成音频
        exit_program = await text_to_speech(text, character, emotion)

        if exit_program:
            break  # 如果用户选择退出，则结束循环

if __name__ == "__main__":
    asyncio.run(main())
